/**
 * background.js - Service Worker Jembatan antara Siskohat Gen.2 (HTTPS 10.100.88.48)
 * dan Sumber Data Biovisa:
 * 1. Cloud GitHub Pages: https://kemenhajkotapasuruan.github.io/e-visa/ (Berfungsi di semua PC tanpa Laragon & tanpa masalah IP Dinamis!)
 * 2. Server Lokal Laragon: http://localhost/e-visa/api.php (atau IP LAN / Hostname)
 */

const GITHUB_PAGES_BASE = 'https://kemenhajkotapasuruan.github.io/e-visa';
const DEFAULT_LOCAL_API = 'http://localhost/e-visa/api.php';

async function getStoredConfig() {
  return new Promise(resolve => {
    chrome.storage.local.get(
      ['evisa_source_mode', 'evisa_api_url', 'gh_cloud_records', 'gh_cloud_images', 'gh_siskohat_done_ids'],
      res => {
        resolve({
          sourceMode: res.evisa_source_mode || 'auto_github', // 'auto_github' | 'github_only' | 'local_only'
          apiUrl: res.evisa_api_url || DEFAULT_LOCAL_API,
          cloudRecords: Array.isArray(res.gh_cloud_records) ? res.gh_cloud_records : [],
          cloudImages: res.gh_cloud_images || {},
          doneIds: res.gh_siskohat_done_ids || {}
        });
      }
    );
  });
}

function arrayBufferToBase64(buffer) {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

/**
 * Ambil daftar antrean Biovisa dari GitHub Pages (https://kemenhajkotapasuruan.github.io/e-visa/)
 * digabung dengan hasil sinkronisasi baru di browser (gh_cloud_records)
 */
async function fetchQueueFromGitHubPages() {
  const { cloudRecords, doneIds } = await getStoredConfig();
  let staticRecords = [];

  try {
    const res = await fetch(`${GITHUB_PAGES_BASE}/storage/data/records.json?_t=${Date.now()}`);
    if (res.ok) {
      const json = await res.json();
      if (Array.isArray(json)) {
        staticRecords = json;
      }
    }
  } catch (e) {}

  // Gabungkan cloudRecords (yang baru ditarik dari Gmail di tab github.io) dengan staticRecords dari repo GitHub
  const byPaspor = new Map();
  for (const r of [...cloudRecords, ...staticRecords]) {
    const key = (r.paspor || r.id || r.filename || '').toUpperCase();
    if (!key || key === 'TANPAPASPOR') continue;
    if (!byPaspor.has(key)) {
      const isDone = !!(r.siskohat_uploaded || doneIds[r.id] || doneIds[r.paspor]);
      byPaspor.set(key, {
        id: r.id || ('bv_' + r.paspor),
        nama: r.nama || '',
        paspor: r.paspor || '',
        enrollment_id: r.enrollment_id || '',
        filename: r.filename || `${r.nama}_${r.paspor}.jpg`,
        size_kb: r.size_kb || 49.2,
        siskohat_uploaded: isDone
      });
    }
  }

  const list = Array.from(byPaspor.values());
  return {
    ok: true,
    source_label: 'GitHub Cloud (kemenhajkotapasuruan.github.io)',
    count: list.length,
    records: list
  };
}

/**
 * Ambil file JPG <= 50KB (Base64) langsung dari GitHub Pages (https://kemenhajkotapasuruan.github.io/e-visa/)
 */
async function fetchBiovisaFileFromGitHubPages(id, paspor, nama) {
  const { cloudImages } = await getStoredConfig();
  const queueRes = await fetchQueueFromGitHubPages();
  const records = queueRes.records || [];

  const matched = records.find(
    r =>
      (id && r.id === id) ||
      (paspor && (r.paspor || '').toUpperCase() === paspor.toUpperCase()) ||
      (nama && (r.nama || '').toUpperCase() === nama.toUpperCase())
  );

  if (!matched) {
    throw new Error('Data jamaah tidak ditemukan di GitHub Pages.');
  }

  const filename = matched.filename;

  // 1. Cek apakah gambar baru dirender di tab GitHub Pages (tersimpan di cloudImages)
  if (cloudImages[filename]) {
    let b64 = cloudImages[filename];
    if (b64.includes(',')) b64 = b64.split(',')[1];
    return {
      ok: true,
      record: {
        ...matched,
        base64: b64
      }
    };
  }

  // 2. Unduh file JPG langsung dari https://kemenhajkotapasuruan.github.io/e-visa/storage/biovisa/<filename>
  const fileUrl = `${GITHUB_PAGES_BASE}/storage/biovisa/${encodeURIComponent(filename)}?_t=${Date.now()}`;
  const imgRes = await fetch(fileUrl);
  if (!imgRes.ok) {
    throw new Error(`File ${filename} belum tersedia di GitHub Pages (HTTP ${imgRes.status}).`);
  }

  const buf = await imgRes.arrayBuffer();
  const b64 = arrayBufferToBase64(buf);
  const sizeKb = Number((buf.byteLength / 1024).toFixed(2));

  return {
    ok: true,
    record: {
      ...matched,
      size_kb: sizeKb,
      base64: b64
    }
  };
}

/**
 * Coba ambil dari Laragon Lokal jika tersedia
 */
async function tryFetchLocalApi(urlWithParams, options = {}, timeoutMs = 1800) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(urlWithParams, { ...options, signal: controller.signal });
    clearTimeout(timer);
    if (!res.ok) return null;
    return await res.json();
  } catch (e) {
    clearTimeout(timer);
    return null;
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      const cfg = await getStoredConfig();

      if (msg.type === 'FETCH_QUEUE') {
        // Jika mode local_only atau auto, cek Laragon lokal dulu (dengan timeout cepat 1.5 detik)
        if (cfg.sourceMode !== 'github_only') {
          const localData = await tryFetchLocalApi(`${cfg.apiUrl}?action=siskohat_queue&_t=${Date.now()}`);
          if (localData && localData.ok) {
            localData.source_label = 'Laragon Lokal';
            sendResponse({ ok: true, data: localData, activeSource: 'local' });
            return;
          }
        }

        // Gunakan GitHub Pages Cloud (https://kemenhajkotapasuruan.github.io/e-visa/)
        const ghData = await fetchQueueFromGitHubPages();
        sendResponse({ ok: true, data: ghData, activeSource: 'github' });
        return;
      }

      if (msg.type === 'FETCH_BIOVISA_FILE') {
        if (cfg.sourceMode !== 'github_only') {
          const params = new URLSearchParams({
            action: 'siskohat_get_file',
            id: msg.id || '',
            paspor: msg.paspor || '',
            nama: msg.nama || ''
          });
          const localFile = await tryFetchLocalApi(`${cfg.apiUrl}?${params.toString()}`, {}, 2000);
          if (localFile && localFile.ok && localFile.record) {
            sendResponse({ ok: true, data: localFile, activeSource: 'local' });
            return;
          }
        }

        // Ambil langsung dari https://kemenhajkotapasuruan.github.io/e-visa/
        const ghFile = await fetchBiovisaFileFromGitHubPages(msg.id, msg.paspor, msg.nama);
        sendResponse({ ok: true, data: ghFile, activeSource: 'github' });
        return;
      }

      if (msg.type === 'MARK_SISKOHAT_UPLOADED') {
        const doneIds = cfg.doneIds || {};
        if (msg.id) {
          if (msg.status !== false) doneIds[msg.id] = true;
          else delete doneIds[msg.id];
        }
        chrome.storage.local.set({ gh_siskohat_done_ids: doneIds });

        // Update juga ke Laragon lokal bila aktif
        await tryFetchLocalApi(
          `${cfg.apiUrl}?action=mark_siskohat`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: msg.id, status: msg.status !== false })
          },
          1500
        );

        sendResponse({ ok: true, data: { ok: true } });
        return;
      }

      if (msg.type === 'LOG_DOM_DEBUG') {
        await tryFetchLocalApi(
          `${cfg.apiUrl}?action=siskohat_dom_debug`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(msg.debug || {})
          },
          1200
        );
        sendResponse({ ok: true });
        return;
      }

      sendResponse({ ok: false, error: 'Unknown message type' });
    } catch (err) {
      sendResponse({
        ok: false,
        error: 'Gagal mengambil data Biovisa: ' + err.message
      });
    }
  })();

  return true;
});
